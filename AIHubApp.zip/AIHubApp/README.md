# AI هب — Android App

د AI پرامپټونو، لینکونو، عکس/ویډیو پرامپټونو او ټرینډ لپاره Android اپلیکیشن (WebView-based).

## ولې دلته compiled APK نشته؟
زه (Claude) دلته د انټرنیټ لاسرسی او Android SDK/Gradle نه لرم، نو دا پروژه نشم کولی چې پخپله APK ته compile کړم.
دا یو بشپړ، سم Android Studio project دی — یوازې دې ته اړتیا ده چې Android Studio کې یې پرانیزئ او Build کړئ.

## د APK جوړولو لاره — یوازې د موبایل سره (پرته له کمپیوټره)

که ته یوازې موبایل لرې، دلته کیدلی شي چې GitHub (وړیا سرویس) ستا لپاره APK جوړ کړي:

### ګامونه:
1. **GitHub حساب جوړ کړه**: [github.com](https://github.com) خلاص کړه (د موبایل براوزر یا GitHub اپ سره) → "Sign up" → وړیا حساب جوړ کړه

2. **نوی repository جوړ کړه**:
   - "+" → "New repository" → یو نوم ورکړه لکه `ai-hub-app` → "Create repository"

3. **دا ټول فایلونه اپلوډ کړه**:
   - په نوي repo کې "Add file" → "Upload files" کلیک کړه
   - دا `AIHubApp.zip` لومړی خپل موبایل کې extract کړه (د Files اپ یا ZIP Extractor اپ سره — ډیری Android فونونه دا وړیا لري)
   - بیا ټول extract شوي فایلونه/فولډرونه یوځای وټاکه او اپلوډ یې کړه (GitHub اپ کې د فولډر اپلوډ اسانه دی؛ براوزر کې ممکن یو-یو فایل اپلوډ کړې)
   - "Commit changes" کلیک کړه

4. **Build به اتومات پیل شي**:
   - پورته "Actions" ټب ته لاړه شه — یو build به هلته روان وي (یو څو دقیقې وخت نیسي)
   - سرغی رنګ (⏳) = روان دی، شنه ✓ = بریالی شو

5. **APK ښکته کړه**:
   - کله چې بریالی شي، پر همغه build کلیک وکړه
   - ښکته "Artifacts" برخه کې به `app-debug-apk` وي — پرې کلیک کړه چې ښکته شي (zip فایل به وي چې دننه APK لري)
   - دا zip extract کړه، APK ترې ترلاسه کړه، او نصب یې کړه

⚠️ **مهمه**: مخکې لدې چې اپلوډ کوې، حتماً د Firebase `firebaseConfig` په `app/src/main/assets/index.html` کې بدل کړه — که نه، اپلیکیشن به کار ونکړي.

که کومه ستونزه راغله (لکه Actions کې red ✗)، پر build کلیک وکړه چې error log وګورې، یا دلته راته ولیکه چې مرسته درسره وکړم.

## د Play Store لپاره خپرول
1. یو **signed release APK/AAB** جوړ کړئ: Build → Generate Signed Bundle/APK
2. [Google Play Console](https://play.google.com/console) کې حساب جوړ کړئ (یو ځلي $25 fee)
3. AAB فایل اپلوډ کړئ، د اپلیکیشن سکرین شاټونه، تشریح، او آیکون اضافه کړئ
4. خپاره کړئ

## مهمه ټکنیکي نوټ — د محتوا ذخیره کول
دا نسخه **Firebase Firestore** کاروي — یعنې ستا پوسټونه به یو مرکزي سرور کې خوندي شي او **هر کاروونکی به یو شان محتوا وویني** (که ته یو پوسټ اضافه کړې، سملاسي به یې نور کاروونکي هم وویني). Bookmarks (📌 خوندي شوي) بیا هم د هر کاروونکي په خپل موبایل کې لوکل پاتې کیږي.

### د Firebase تنظیمولو ګامونه (اړین دی، پرته له دې اپلیکیشن کار نه کوي)
1. لاړه [console.firebase.google.com](https://console.firebase.google.com) ته او "Add project" کلیک کړه (وړیا دی)
2. کله چې پروژه جوړه شي، بائیں اړخ کې "Build" → "Firestore Database" → "Create database" کلیک کړه
   - Location هر ځای غوره کړه (نږدې یو غوره کړه)
   - "Start in **test mode**" غوره کړه (چې ژر پیل شي — وروسته یې امنیت configure کولی شې)
3. بیرته "Project settings" (⚙️ آیکون) → لاندې "Your apps" → د `</>` (Web) آیکون کلیک کړه
4. یو نوم ورکړه، "Register app" کلیک کړه — دا به درته یو `firebaseConfig` object ورکړي لکه:
   ```js
   const firebaseConfig = {
     apiKey: "AIza...",
     authDomain: "your-project.firebaseapp.com",
     projectId: "your-project-id",
     ...
   };
   ```
5. دا بشپړ object کاپي کړه او په دواړو فایلونو کې (`ai-hub.html` او `AIHubApp/app/src/main/assets/index.html`) کې د `YOUR_API_KEY` او نورو placeholder ارزښتونو ځای ونیسه (لټون یې کوه: `const firebaseConfig`)
6. خوندي کړه — بس، اوس به ټول کاروونکي یو شان محتوا وویني

⚠️ **د امنیت خبرداری:** "test mode" هرچا ته اجازه ورکوي چې ستاسو ډیټابیس ولولي/ولیکي، چې د پیل کولو لپاره ښه دی خو د اصلي خپرولو دمخه باید Firestore security rules سم کړئ (ترڅو یوازې ته پوسټونه اضافه/حذف کولی شې).

## فایلونه
- `app/src/main/assets/index.html` — ټول UI (HTML/CSS/JS)، د ویب نسخې سره یو شان
- `app/src/main/java/com/aihub/app/MainActivity.kt` — WebView wrapper + storage bridge
- `app/build.gradle.kts` — dependencies او د اپلیکیشن تنظیمات (package name: `com.aihub.app`)

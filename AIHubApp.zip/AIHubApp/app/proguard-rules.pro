# Default rules — add project-specific ProGuard rules here if needed.
